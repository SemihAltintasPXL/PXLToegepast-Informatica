package be.pxl.h5.opdracht11;

public class FigurenApp {
    public static void main(String[] args) {
        GrafischElement[] lijst = new GrafischElement[5];
        lijst[0] = new Rechthoek(1,2,3,4);
        lijst[1] = new Cirkel(1,2,3);
        lijst[2] = new Driehoek(2,3,4,5,6);
        lijst[3] = new Vierkant(2);
        lijst[4] = new Rechthoek(4,5,6,7);

        for(GrafischElement figuur:lijst) {
            System.out.printf("Omtrek:%8.2f Oppervlakte: %8.2f %10S%n",
                    figuur.getOmtrek(), figuur.getOppervlakte(), figuur.getClass().getSimpleName());
            if(figuur instanceof Cirkel) {
                Cirkel c = (Cirkel) figuur;
                System.out.println(c.getStraal());
            }
        }
    }
}
