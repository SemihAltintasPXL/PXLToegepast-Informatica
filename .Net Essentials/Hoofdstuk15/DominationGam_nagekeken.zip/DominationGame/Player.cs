﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DominationGame
{
    public enum Player
    {
        red, blue, none // liefst laten beginnen met een hoofdletter zou je kunnen beschouwen als een constante
    }
}
