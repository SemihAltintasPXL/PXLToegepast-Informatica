package be.pxl.h5.opdracht8;

public class FigurenApp {
    public static void main(String[] args) {

        Cirkel cirkel = new Cirkel(1,1,1);
        Cirkel cirkel2 = new Cirkel(1,1,1);

        System.out.printf("Omtrek: %.2f, opp: %.2f%n", cirkel.getOmtrek(), cirkel.getOppervlakte());

        if(cirkel == cirkel2) {
            System.out.println("==");
        }
        if(cirkel.equals(cirkel2)) {
            System.out.println("equals()");
        }
    }
}
