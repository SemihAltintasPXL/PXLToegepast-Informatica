﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example1Interfaces
{
    public interface IScaleable
    {
        void Scale(double factor);
    }
}
