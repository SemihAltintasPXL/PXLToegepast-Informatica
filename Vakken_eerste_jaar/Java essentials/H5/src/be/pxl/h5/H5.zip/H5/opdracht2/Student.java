package be.pxl.h5.demo;

public class Student extends Persoon {

}
