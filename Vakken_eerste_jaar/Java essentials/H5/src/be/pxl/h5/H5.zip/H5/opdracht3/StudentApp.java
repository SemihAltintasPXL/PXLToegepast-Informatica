package be.pxl.h5.demo;

public class StudentApp {
    public static void main(String[] args) {
        Student student = new Student();

        student.setVoornaam("Sam");
        student.setNaam("Vanderstraeten");
        student.print();

        student.setLeerkrediet(-100);
        System.out.println(student.getLeerkrediet());

        student.setLeerkrediet(120);
        System.out.println(student.getLeerkrediet());

        student.wijzigLeerkrediet(50);
        System.out.println(student.getLeerkrediet());
    }
}
