package be.pxl.h5.demo;

public class Student extends Persoon {
    private String studentenNummer;
    private int leerkrediet;
    private String opleiding;

    public String getStudentenNummer() {
        return studentenNummer;
    }

    public void setStudentenNummer(String studentenNummer) {
        this.studentenNummer = studentenNummer;
    }

    public int getLeerkrediet() {
        return leerkrediet;
    }

    public void setLeerkrediet(int leerkrediet) {
        if(leerkrediet < 0) {
            leerkrediet = 0;
        }
        if(leerkrediet > 140) {
            leerkrediet = 140;
        }
        this.leerkrediet = leerkrediet;
    }

    public void wijzigLeerkrediet(int verschil) {
        int nieuwLeerkrediet = leerkrediet + verschil;
        setLeerkrediet(nieuwLeerkrediet);
    }

    public String getOpleiding() {
        return opleiding;
    }

    public void setOpleiding(String opleiding) {
        this.opleiding = opleiding;
    }
}
