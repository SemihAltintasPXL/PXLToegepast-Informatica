package be.pxl.h5.oefening3;

import java.util.Random;

public class Archer extends Human{
    Bow bow;
    public Archer(String naam){
        super(naam);
        bow = new Bow(10, 5);
        setWeapon(bow);
    }
    public void findArrows(){
        Random random = new Random();
        int aantal_pijlen = random.nextInt(10) + 1;
        bow.addArrows(aantal_pijlen);

    }
    public void attack(Character opponent){
        opponent.decreaseHealth(bow.doDamage());
        speak("Attacking " + opponent.getName() + " with my bow!");
    }

    @Override
    public void setWeapon(Weapon weapon) {
        if (!(weapon instanceof Bow)){
            speak("I only know how to shoot a bow");
        }
    }
}
