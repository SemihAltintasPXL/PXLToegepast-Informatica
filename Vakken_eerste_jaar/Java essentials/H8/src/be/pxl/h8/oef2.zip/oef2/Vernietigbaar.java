package be.pxl.h8.oef2;

public interface Vernietigbaar {

    void ontvangSchade(int schade);
}
