package be.pxl.h8.oef2;

public interface Beweegbaar {
    void beweegNaar(Punt punt);
}
