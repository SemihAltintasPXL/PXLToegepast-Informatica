package be.pxl.h5.oefening3;

public class Warrior extends Human{
    Sword sword;

    public Warrior(String name){
        super(name);
        sword = new Sword(10);
        setWeapon(sword);

    }

    public void attack(Character opponent) {
        opponent.decreaseHealth(sword.doDamage());
        speak("Attacking " + opponent.getName() + " with my sword!");
    }

    public void setWeapon(Weapon weapon) {
        if (!(weapon instanceof Sword)){
            speak("I only know how to swing swords and axes!");
        }
    }

}
