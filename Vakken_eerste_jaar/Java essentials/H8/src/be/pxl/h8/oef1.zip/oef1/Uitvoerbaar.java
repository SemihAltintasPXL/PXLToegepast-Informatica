package be.pxl.h7.oef1;

public interface Uitvoerbaar {

    void voeruit();
}
