package be.pxl.h5.opdracht11;

import java.util.Objects;

public class Cirkel extends GrafischElement {

    private double straal;

    public Cirkel(int x, int y, double straal) {
        super(x,y);
        this.straal = straal;
    }

    public double getStraal() {
        return straal;
    }

    public void setStraal(double straal) {
        this.straal = straal;
    }

    @Override
    public String toString() {
        return "Cirkel met straal " + straal + " @" + super.toString();
    }

    @Override
    public double getOmtrek() {
        return 2 * Math.PI * straal;
    }

    @Override
    public double getOppervlakte() {
        return Math.PI * straal * straal; // Math.pow(straal, 2)
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Cirkel cirkel = (Cirkel) o;
        return Double.compare(cirkel.straal, straal) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), straal);
    }
}
