package be.pxl.h5.demo;

import java.util.ArrayList;

public class StudentApp {
    public static void main(String[] args) {
        Student student = new Student();
        student.setVoornaam("Sam");
        student.setNaam("Vanderstraeten");
        student.print();

        Lector lector = new Lector();
        lector.setVoornaam("Arno");
        lector.setNaam("Barzan");
        lector.setPersoneelsnummer("2342525");
        lector.setSalaris(10000);
        lector.setAanstellingsPercentage(150);
        lector.print();

        lector.setAanstellingsPercentage(75);
        lector.print();
    }
}
