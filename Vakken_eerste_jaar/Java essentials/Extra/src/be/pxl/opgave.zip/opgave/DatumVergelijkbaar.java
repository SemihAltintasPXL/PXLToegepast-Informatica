package be.pxl.opgave;

import java.time.LocalDateTime;

public interface DatumVergelijkbaar {
    long berekenAantalMinutenNa(LocalDateTime dateTime);
}
