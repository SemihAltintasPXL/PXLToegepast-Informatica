package be.pxl.h8.oef2;

public enum Alliantie {
    NOORD, ZUID
}
